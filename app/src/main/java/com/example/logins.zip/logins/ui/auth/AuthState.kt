package com.example.logins.ui.auth

import androidx.compose.runtime.mutableStateOf

object AuthState {
    var isAuthenticated = mutableStateOf(false)
}