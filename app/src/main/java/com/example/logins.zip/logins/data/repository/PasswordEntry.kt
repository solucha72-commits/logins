package com.example.logins.data.repository

data class PasswordEntry(
    val id: String,
    val family: String,
    val password: String
)